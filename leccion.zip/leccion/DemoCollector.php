<?php

include_once('Demo.php');
include_once('Collector.php');

class DemoCollector extends Collector
{
  
  function showDemos() {
    $rows = self::$db->getRows("SELECT * FROM calificaciones ");        
    echo "linea 1";
    $arrayDemo= array();        
    foreach ($rows as $c){
      $aux = new calificacion($c{'id'},$c{'Nombre'},$c{'Parcial'},$c{'Final'},$c{'Mejoramiento'},$c{'Aprueba'});
      array_push($arrayDemo, $aux);
    }
    return $arrayDemo;        
  }

  function delete($i) {
     $rows = self::$db->getRows("DELETE FROM calificaciones where id= $i");         
    }
         

  function insert($id, $nombre,$parcial,$finall,$mejoramiento,$aprueba) {
     $rows = self::$db->getRows("INSERT INTO calificaciones(id,Nombre,Parcial,Final,Mejoramiento,Aprueba) VALUES ($id, $nombre,$parcial,$finall,$mejoramiento,$aprueba)");         
    }

}
?>

