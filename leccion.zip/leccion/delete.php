<?php
session_start();
?>
<?php
include_once("DemoCollector.php");
 echo "Hola ".$_SESSION['nombre'];
$id = $_GET['id'];

$DemoCollectorObj = new DemoCollector();

$DemoCollectorObj->delete($id);

 

?>
<a href = "logout.php">salir</a>

