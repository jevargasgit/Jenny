<?php
//session_start();
?>

<?php
include_once("DemoCollector.php");


// echo "<p> Hola usuario:(" .$_SESSION['nombre']. ") 
//[<a href='index.php'>Salir</a>]";

$DemoCollectorObj = new DemoCollector();

foreach ($DemoCollectorObj->showDemos() as $c){
  echo "<div>";
  echo $c->getId() . "  && " .$c->getNombre() . "  && " .$c->getParcial() . "  && " .$c->getFinall(). "  && " .$c->getMejoramiento(). "  && " .$c->getAprueba(); 
  echo "<a href='delete.php?id=".$c->getId()."'>Eliminar</a> " ;                               
  echo "</div>"; 

}


?>
