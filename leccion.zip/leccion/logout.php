<?php
session_start();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>PSW + Cookie pagina + nombre</title>
  <link type="text/css" rel="stylesheet" href="css/main.css" />
</head>
<body>
  <header> 
  </header> 
  <section id="sidebar">    
  </section>
  <section id="main">
  <?php
 
  if (isset($_SESSION['nombre'])){
    session_destroy();
    echo "se ha destruido session exitosamente <br/>";
    echo "<a href='index.php'>Volver</a>";
  }else{
    echo "ERROR... <br/>";
    echo "<a href='index.php'>Volver</a>";
  
  }
  
  ?> 
  </section>  

  <aside> 
    <object type="image/jpeg" data="image/publicidad.jpg" width="200" height="200"> </object>
  </aside> 

  <footer> 
  </footer> 

</body>
</html>
