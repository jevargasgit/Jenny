<?php

class calificacion
{
    private $id;
    private $nombre;
    private $parcial;
    private $finall;
    private $mejoramiento;
    private $aprueba;
    
     function __construct($id, $nombre,$parcial,$finall,$mejoramiento,$aprueba) {
       $this->idDemo = $id;
       $this->nombre = $nombre;
       $this->parcial = $parcial;
       $this->finall = $finall;
       $this->mejoramiento = $mejoramiento;
       $this->aprueba = $aprueba;
     }
    
     function setId($id){
       $this->id = $id;
     } 
     function getId(){
       return $this->id;
     } 
     function setNombre($nombre){
       $this->nombre = $nombre;
     } 
     function getNombre(){
       return $this->nombre;
     } 
     function setParcial($parcial){
       $this->parcial = $parcial;
     } 
     function getParcial(){
       return $this->parcial;
     } 
     function setFinall($finall){
       $this->finall = $finall;
     } 
     function getFinall(){
       return $this->finall;
     } 
     function setMejoramiento($mejoramiento){
       $this->mejoramiento = $mejoramiento;
     } 
     function getMejoramiento(){
       return $this->mejoramiento;
     } 
     function setAprueba($aprueba){
       $this->aprueba = $aprueba;
     } 
     function getAprueba(){
       return $this->aprueba;
     } 


}



?> 
