<?php
session_start();
?>

<?php
include_once("DemoCollector.php");


 echo "<p> Hola usuario:(" .$_SESSION['nombre']. ") 
[<a href='index.php'>Salir</a>]";

$DemoCollectorObj = new DemoCollector();

foreach ($DemoCollectorObj->showDemos() as $c){
  echo "<div>";
  echo $c->getIdDemo() . "  && " .$c->getNombre();                                     
  echo "</div>"; 
}


?>
