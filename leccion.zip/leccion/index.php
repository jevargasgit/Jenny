<?php
  //session_start();
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>PSW + Cookie en PHP</title>
  <link type="text/css" rel="stylesheet" href="css/main.css" />
</head>
<body>
  <header> 
    <nav> 
      <a href="inicio.html">Inicio</a> 
      <a href="nosotros.html">Nosotros</a> 
      <a href="Servicios.html">Servicios</a> 
      <a href="Contactenos.html">Contáctenos</a> 
    </nav> 
  </header> 
  <section id="sidebar">    
  </section>
  <section id="main">
 
  
  </section>  

  <aside> 
  
  <?php
  
  //if (isset($_SESSION['nombre'])){
  //  echo "<p> Hola usuario:(" . $_SESSION['nombre']. ") [<a href='logout.php'>Salir</a>]";
  //}
  //else{  
    ?>
    <form action="admin.php" method="post">
      <p>Nombre: <input type="text" name="nombre" /></p>
	<p>Parcial: <input type="text" name="parcial" /></p>
	<p>Final: <input type="text" name="final" /></p>
	<p>Mejoramiento: <input type="text" name="mejoramiento" /></p>
      <p><input type="submit" value="Enviar" /></p>
    </form>    
   <?php ?>
    <object type="image/jpeg" data="image/publicidad.jpg" width="200" height="200"> </object>
  </aside> 

  <footer> 
    <div>Derechos reservados</div>
    <div>Contactenos en edcom@espol.edu.ec</div>
  </footer> 

</body>
</html>
