<?php
//session_start();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>PSW + Cookie pagina + nombre</title>
  <link type="text/css" rel="stylesheet" href="css/main.css" />
</head>
<body>
  <header> 
  </header> 
  <section id="sidebar">    
  </section>
  <section id="main">
<?php 

    $_SESSION['nombre']= $_POST['nombre'];
    echo "variable:" . $_SESSION['nombre'];
    echo "<a href='create.php'>crear</a>";

?>
  </section>  

  <aside> 
    <object type="image/jpeg" data="image/publicidad.jpg" width="200" height="200"> </object>
  </aside> 

  <footer> 
  </footer> 

</body>
</html>
